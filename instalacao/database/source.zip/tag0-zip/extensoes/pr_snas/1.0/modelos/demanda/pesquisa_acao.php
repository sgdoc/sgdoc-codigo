<?php

//try {
//    $sttm = Controlador::getInstance()
//		->getConnection()
//		->connection
//		->prepare("SELECT * FROM SGDOC_DEMANDA.TB_TESTE");
//
//    $sttm->execute();
//    $out = $sttm->fetchAll(PDO::FETCH_ASSOC);
//
//    var_dump($out); die;
//
//} catch (PDOException $e) {
//    $str = FAILED;
//}
//
//die('finalizou');