<?php
/**
 * TODO Auto-generated comment.
 */
class IniciativaDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($iniciativa) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($iniciativa) {
		return null;
	}
}
