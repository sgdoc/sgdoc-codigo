<?php
/**
 * TODO Auto-generated comment.
 */
class MacroDesafioDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($macroDesafio) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($macroDesafio) {
		return null;
	}
}
