<?php
/**
 * TODO Auto-generated comment.
 */
class momentoDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $dt_alteracao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descicao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $ativo;
}
