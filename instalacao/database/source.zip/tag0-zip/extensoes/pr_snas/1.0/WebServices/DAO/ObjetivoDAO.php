<?php
/**
 * TODO Auto-generated comment.
 */
class ObjetivoDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($objetivo) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($objetivo) {
		return null;
	}
}
