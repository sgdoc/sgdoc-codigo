<?php
/**
 * TODO Auto-generated comment.
 */
class TipoProgramaDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($tipoPrograma) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($tipoPrograma) {
		return null;
	}
}
