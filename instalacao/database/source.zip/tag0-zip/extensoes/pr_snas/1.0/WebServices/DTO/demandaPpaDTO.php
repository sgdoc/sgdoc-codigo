<?php
/**
 * TODO Auto-generated comment.
 */
class demandaPpaDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_programa;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_objetivo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_meta;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_iniciativa;
	/**
	 * TODO Auto-generated comment.
	 */
	public $vodigo_acao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_execucao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_demanda;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descricao;
}
