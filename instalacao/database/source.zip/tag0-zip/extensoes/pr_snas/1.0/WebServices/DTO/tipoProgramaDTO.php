<?php
/**
 * TODO Auto-generated comment.
 */
class tipoProgramaDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descricao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $ativo;
}
