<?php
/**
 * TODO Auto-generated comment.
 */
class objetivoDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $momento;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $orgao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $id_Programa;
	/**
	 * TODO Auto-generated comment.
	 */
	public $enunciado;
	/**
	 * TODO Auto-generated comment.
	 */
	public $excluido;
}
