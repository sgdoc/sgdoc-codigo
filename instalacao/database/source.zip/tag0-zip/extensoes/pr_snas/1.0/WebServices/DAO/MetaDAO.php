<?php
/**
 * TODO Auto-generated comment.
 */
class MetaDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($meta) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($meta) {
		return null;
	}
}
