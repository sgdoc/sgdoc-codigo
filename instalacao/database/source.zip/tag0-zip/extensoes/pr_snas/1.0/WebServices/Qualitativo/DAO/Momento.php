<?php
/**
 * TODO Auto-generated comment.
 */
class Momento {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($momento) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($momento) {
		return null;
	}
}
