<?php
/**
 * TODO Auto-generated comment.
 */
class macroDesafioDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descricao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $titulo;
}
