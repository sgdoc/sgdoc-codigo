<?php
/**
 * TODO Auto-generated comment.
 */
class programaDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $macroDesafio;
	/**
	 * TODO Auto-generated comment.
	 */
	public $momento;
	/**
	 * TODO Auto-generated comment.
	 */
	public $orgao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $tipoPrograma;
	/**
	 * TODO Auto-generated comment.
	 */
	public $estrategia_implementacao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $exercicio;
	/**
	 * TODO Auto-generated comment.
	 */
	public $horizonte_temporal_continuo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $justificativa;
	/**
	 * TODO Auto-generated comment.
	 */
	public $objetivo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $objetivos;
	/**
	 * TODO Auto-generated comment.
	 */
	public $problema;
	/**
	 * TODO Auto-generated comment.
	 */
	public $publico_alvo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $excluido;
	/**
	 * TODO Auto-generated comment.
	 */
	public $titulo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $unidade_responsavel;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descricao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $sigla;
}
