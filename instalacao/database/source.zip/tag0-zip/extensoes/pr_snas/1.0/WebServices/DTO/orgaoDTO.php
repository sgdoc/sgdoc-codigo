<?php
/**
 * TODO Auto-generated comment.
 */
class orgaoDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $tipo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_pai;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descricao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $descricao_abreviada;
}
