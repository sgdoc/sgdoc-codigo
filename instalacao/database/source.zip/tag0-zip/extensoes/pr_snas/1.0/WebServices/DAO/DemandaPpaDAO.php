<?php
/**
 * TODO Auto-generated comment.
 */
class DemandaPpaDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($demandaPpa) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($demandaPpa) {
		return null;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function alterar($demandaPpa) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function listar($demandaPpa) {
		return null;
	}
}
