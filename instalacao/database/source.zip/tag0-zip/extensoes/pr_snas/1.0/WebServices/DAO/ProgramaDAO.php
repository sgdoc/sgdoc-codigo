<?php
/**
 * TODO Auto-generated comment.
 */
class ProgramaDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($programa) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($programa) {
		return null;
	}
}
