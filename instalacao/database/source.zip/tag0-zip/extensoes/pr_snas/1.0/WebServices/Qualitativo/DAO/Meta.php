<?php
/**
 * TODO Auto-generated comment.
 */
class Meta {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($meta) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($meta) {
		return null;
	}
}
