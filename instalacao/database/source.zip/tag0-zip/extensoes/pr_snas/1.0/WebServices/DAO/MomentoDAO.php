<?php
/**
 * TODO Auto-generated comment.
 */
class MomentoDAO {

	/**
	 * TODO Auto-generated comment.
	 */
	public function inserir($momento) {
		return false;
	}

	/**
	 * TODO Auto-generated comment.
	 */
	public function pesquisar($momento) {
		return null;
	}
}
