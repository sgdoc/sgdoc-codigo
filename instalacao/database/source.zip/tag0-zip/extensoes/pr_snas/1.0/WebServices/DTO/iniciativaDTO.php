<?php
/**
 * TODO Auto-generated comment.
 */
class iniciativaDTO {
	/**
	 * TODO Auto-generated comment.
	 */
	public $id;
	/**
	 * TODO Auto-generated comment.
	 */
	public $momento;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_objetivo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_orgao;
	/**
	 * TODO Auto-generated comment.
	 */
	public $codigo_programa;
	/**
	 * TODO Auto-generated comment.
	 */
	public $individualizada;
	/**
	 * TODO Auto-generated comment.
	 */
	public $titulo;
	/**
	 * TODO Auto-generated comment.
	 */
	public $excluido;
}
