#! /bin/sh
wget -q --no-check-certificate https://dsvm.sgdoc.sisicmbio.icmbio.gov.br/cron/geraPng.php
rm -rf geraPng.php.*