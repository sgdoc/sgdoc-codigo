<?php

namespace grid;

use grid\GridAbstract;

/**
 * @author Michael F. Rodrigues <cerberosnash@gmail.com>
 * @version 0.0.0
 */
class Grid extends GridAbstract
{
    
}